from django.shortcuts import render, redirect
from django.views import View
from django.contrib import messages
from django.db.models import Q
from api.models import *
from api.forms import *
from api.utils import *

from datetime import datetime, timedelta


class IndexView(View):
    """
    主页
    """
    def get(self, request):
        return redirect('/login/')


class LoginView(View):
    """
    登录
    """
    def get(self, request):
        if request.session.get('is_login', None):
            return redirect('/home/')
        login_form = LoginForm()
        return render(request, 'login.html', locals())

    def post(self, request):
        login_form = LoginForm(request.POST)
        message = '请检查填写的内容！'
        if login_form.is_valid():
            username = login_form.cleaned_data['username']
            password = login_form.cleaned_data['password']
            authuser = CustomUser.objects.filter(username=username).first()
            if authuser is None or authuser.is_deleted:
                message = 'no user'
            elif password != authuser.password:
                message = '用户名或密码错误！'
            else:
                request.session['is_login'] = True
                request.session['username'] = authuser.username
                return redirect('/home/')
        return render(request, 'login.html', locals())


class LogoutView(View):
    """
    登出
    """
    def get(self, request):
        if request.session.get('is_login', None):
            request.session.flush()
            messages.success(request, '退出成功！')
        return redirect('/login/')


class HomeView(View):
    """
    个人中心
    """
    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')

        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()

        if isUserRedirect(request):
            return redirect('/request/')

        all_users = CustomUser.objects.filter(is_deleted=False)
        # borrow_entries = Borrow.objects.filter(user_id=user_id)
        return render(request, 'home.html', locals())


class AddUserPermissionView(View):
    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')

        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()
        
        if isUserRedirect(request):
            return redirect('/request/')

        if authuser.role != 2:
            messages.error(request, '不是超级管理员，不能为给人增加权限！')
            return redirect('/home/')

        user_id = request.GET.get('user_id')
        user = CustomUser.objects.filter(id=user_id).first()
        user.role = 1
        user.save()
        return redirect('/home/')


class RemoveUserPermissionView(View):
    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')

        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()
        
        if isUserRedirect(request):
            return redirect('/request/')

        if authuser.role != 2:
            messages.error(request, '不是超级管理员，不能解除别人的权限！')
            return redirect('/home/')

        user_id = request.GET.get('user_id')
        user = CustomUser.objects.filter(id=user_id).first()
        user.role = 0
        user.save()
        return redirect('/home/')



class AddUserView(View):
    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')
        adduser_form = AddUserForm(request.POST)
        
        if isUserRedirect(request):
            return redirect('/request/')

        return render(request, 'adduser.html', locals())

    def post(self, request):
        if isUserRedirect(request):
            return redirect('/request/')
        adduser_form = AddUserForm(request.POST)
        message = '请检查填写的内容！'
        if adduser_form.is_valid():
            username = adduser_form.cleaned_data['username'] 
            gender = adduser_form.cleaned_data['gender'] 
            phone = adduser_form.cleaned_data['phone'] 
            password = adduser_form.cleaned_data['password'] 
            email = adduser_form.cleaned_data['email']

            user = CustomUser.objects.filter(username=username).first()
            if user is not None:
                message = '用户已注册'
            else:
                CustomUser.objects.create(
                    username=username,
                    gender=gender,
                    phone=phone,
                    email=email,
                    password=password
                )
                messages.success(request, '增加用户成功！')
                return redirect('/home/')
        return render(request, 'adduser.html', locals())
    
class DeleteUserView(View):
    def get(self, request):
        if isUserRedirect(request):
            return redirect('/request/')
        user_id = request.GET.get('user_id')
        user = CustomUser.objects.filter(id=user_id).first()
        user.is_deleted = 1
        user.save()
        return redirect('/home/')

class RequestView(View):
    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')

        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()
        
        status = request.GET.get('status')
        if status is None:
            all_records = Record.objects.filter(Q(user__username=username) & Q(type="out"))
        else:
            all_records = Record.objects.filter(Q(user__username=username) & Q(type="out") & Q(status=status))
        return render(request, 'request.html', locals())
    
class AddRequestView(View):
    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')
        addrequest_form = AddRequestForm(request.POST)
        
        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()
        
        return render(request, 'addrequest.html', locals())

    def post(self, request):
        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()
        addrequest_form = AddRequestForm(request.POST)
        message = '请检查填写的内容！'
        if addrequest_form.is_valid():
            productname = addrequest_form.cleaned_data['productname'] 
            producttype = addrequest_form.cleaned_data['producttype'] 
            qty = addrequest_form.cleaned_data['qty'] 
            address = addrequest_form.cleaned_data['address'] 
            price = addrequest_form.cleaned_data['price']
        
            product = Product.objects.filter(name=productname).first()
            if product is None:
                product = Product()
                product.name = productname
                product.type = producttype
                product.save()

            user = CustomUser.objects.filter(username=request.session['username']).first()

            record = Record()
            record.qty = qty
            record.type = 'out'
            record.status = 0   # 待处理
            record.product = product
            record.user = user
            record.address = address
            record.price = price
            record.save()
        return redirect('/request/')
    

class ResolveView(View):
    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')

        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()
        if isUserRedirect(request):
            return redirect('/request/')

        status = request.GET.get('status')
        if status is None:
            all_records = Record.objects.filter(Q(type="out"))
        else:
            all_records = Record.objects.filter(Q(type="out") & Q(status=status))
        
        return render(request, 'resolve.html', locals())


class ResolveAcceptView(View):
    def get(self, request):
        if isUserRedirect(request):
            return redirect('/request/')
        
        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()

        record_id = request.GET.get('record_id')
        record = Record.objects.filter(id=record_id).first()
        if record.price > 0:
            moneyResource = Storage.objects.filter(product__name='金额').first()
            if moneyResource.price < record.price:
                messages.error(request, '存款不足！不可出库')
                return redirect('/resolve/')
            else:
                moneyResource.price -= record.price
                moneyResource.withdrawPrice += record.price # out number
                moneyResource.save()
        
        # 检查物件数量
        if record.product.name != '金额':
            resource = Storage.objects.filter(product=record.product).first()
            if resource.qty < record.qty:
                messages.error(request, '物资不足！不可出库')
                return redirect('/resolve/')
            else:
                resource.qty -= record.qty
                resource.withdrawQty += record.qty
                resource.save()

        record.status = 1   # 出库
        record.save()
        return redirect('/resolve/')

class ResolveRejectView(View):
    def get(self, request):
        if isUserRedirect(request):
            return redirect('/request/')

        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()

        record_id = request.GET.get('record_id')
        record = Record.objects.filter(id=record_id).first()
        record.status = 2   # 拒绝
        record.save()
        return redirect('/resolve/')


class ResourceView(View):
    def get(self, request):
        if isUserRedirect(request):
            return redirect('/request/')

        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')

        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()
        
        all_resources = Storage.objects.filter()
        return render(request, 'resource.html', locals())
    
class AddResourceView(View):
    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')

        if isUserRedirect(request):
            return redirect('/request/')

        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()

        addresource_form = AddResourceForm(request.POST)
        return render(request, 'addresource.html', locals())



    def post(self, request):
        if isUserRedirect(request):
            return redirect('/request/')
        
        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()

        addresource_from = AddResourceForm(request.POST)
        message = '请检查填写的内容！'
        if addresource_from.is_valid():
            productname = addresource_from.cleaned_data['productname'] 
            producttype = addresource_from.cleaned_data['producttype'] 
            qty = int(addresource_from.cleaned_data['qty'])
            price = int(addresource_from.cleaned_data['price'])
        
            product = Product.objects.filter(name=productname).first()
            if product is None:
                product = Product()
                product.name = productname
                product.type = producttype
                product.save()

            user = CustomUser.objects.filter(username=request.session['username']).first()

            storage = Storage.objects.filter(product=product).first()
            if storage is None:
                storage = Storage()
                storage.product = product
                storage.qty = qty
                if product.name == '金额':
                    storage.price = price
                storage.save()
            else:
                storage.qty = int(storage.qty) + qty
                if product.name == '金额':
                    storage.price = int(storage.price) + price
                storage.save()

            if product.name != '金额' and price > 0:
                priceStorage = Storage.objects.filter(product__name="金额").first()
                priceStorage.price = int(priceStorage.price) + price
                priceStorage.save()

            record = Record()
            record.qty = qty
            record.type = 'in'
            record.status = 0   # 待处理
            record.product = product
            record.price = price
            record.save()
        return redirect('/resource/')
    
class NotificationView(View):
    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')

        username = request.session['username']
        authuser = CustomUser.objects.filter(username=username).first()
        status = request.GET.get('status')
        if status is None:
            if authuser.role == 0:
                all_records = Record.objects.filter(user=authuser).order_by('-updatedAt')
            else:
                all_records = Record.objects.filter().order_by('-updatedAt')
        else:
            if authuser.role == 0:
                all_records = Record.objects.filter(Q(user=authuser) & Q(type='out') & Q(status=status)).order_by('-updatedAt')
            else:
                all_records = Record.objects.filter(Q(type='out') & Q(status=status)).order_by('-updatedAt')
        
        return render(request, 'notification.html', locals())