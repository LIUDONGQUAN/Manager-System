from api.models import CustomUser
from django.shortcuts import redirect

def isUserRedirect(request):
    username = request.session['username']
    authuser = CustomUser.objects.filter(username=username).first()
    if authuser.role == 0:
        return True