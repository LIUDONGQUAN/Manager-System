import uuid
from django.utils import timezone
from django.db import models

class Record(models.Model):
    id = models.AutoField(primary_key=True)
    product = models.ForeignKey("Product", related_name="product_flow", on_delete=models.CASCADE, null=True)
    qty = models.IntegerField(default=0)
    storage = models.ForeignKey("Storage", related_name="storage_flow", on_delete=models.CASCADE, null=True)
    address = models.CharField(max_length=150)
    type = models.CharField(max_length=150)
    status = models.IntegerField(default=0)
    user = models.ForeignKey("CustomUser", related_name="user_flow", on_delete=models.CASCADE, null=True)
    price = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    
    createdAt = models.DateTimeField(default=timezone.now)
    updatedAt = models.DateTimeField(default=timezone.now)