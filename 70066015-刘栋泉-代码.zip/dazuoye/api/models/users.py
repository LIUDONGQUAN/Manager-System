import uuid

from django.contrib.auth.hashers import make_password
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager


class CustomUserManager(BaseUserManager):
    # Method for creating normal user
    def create_user(self, email, username, password, **other_fields):
        if not email:
            raise ValueError(_("You must provide an email address"))

        email = self.normalize_email(email)
        newUser = self.model(email=email, username=username, **other_fields)
        newUser.set_password(password)
        newUser.save()
        return newUser

    # Method for creating superuser
    def create_superuser(self, email, username, password, **other_fields):
        other_fields.setdefault('is_staff', True)
        other_fields.setdefault('is_superuser', True)
        other_fields.setdefault('is_active', True)

        if other_fields.get('is_staff') is not True:
            raise ValueError(_("Superuser must have is_staff = True."))
        if other_fields.get('is_superuser') is not True:
            raise ValueError(_("Superuser must have is_superuser = True."))

        return self.create_user(email, username, password, **other_fields)

# Custom User Model
class CustomUser(AbstractBaseUser, PermissionsMixin):

    GENDER = (
        ('O', 'Prefer Not to Say'),
        ('M', 'Male'),
        ('F', 'Female'),
    )

    CATEGORY = (
        (0, '普通用户'),
        (1, '管理员'),
        (2, '超级管理员'),
    )

    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=150, unique=True)
    real_name = models.CharField(max_length=150,blank=True)
    email = models.EmailField(unique=True)
    bio = models.TextField(max_length=500, default = "A bio hasn't been added yet.")
    is_staff = models.BooleanField(default=False)
    phone = models.CharField(max_length=150,blank=True)
    # activated at email validation only, not at registration.
    is_active = models.BooleanField(default=True)
    is_deleted = models.BooleanField(default=False)
    gender = models.CharField(max_length=10, choices=GENDER, default=GENDER[0][0])
    
    role = models.IntegerField(choices=CATEGORY, default=0)
    createdAt = models.DateTimeField(default=timezone.now)
    updatedAt = models.DateTimeField(default=timezone.now)
    
    objects = CustomUserManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['email']

    # USERNAME_FIELD = 'username'
    # REQUIRED_FIELDS = ['email',]

    # class Meta:
    #     app_label = 'api'

    def __str__(self):
        return f'{self.username} ({self.id})'

    def has_perm(self, perm, obj=None):
        """
        A method used to check if the user has permission
        """
        return True

    def tokens(self):
        """
        A method used to get the token of user
        """
        return get_tokens(self)

    def set_password(self, raw_password):
        self.password = make_password(raw_password,"a","pbkdf2_sha1")
        self._password = raw_password
