import uuid
from django.utils import timezone
from django.db import models

class Storage(models.Model):
    id = models.AutoField(primary_key=True)
    product = models.ForeignKey("Product", on_delete=models.CASCADE, null=True)
    price = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    qty = models.IntegerField(default=0)
    withdrawQty = models.IntegerField(default=0)
    withdrawPrice = models.DecimalField(max_digits=5, decimal_places=2, default=0)
    createdAt = models.DateTimeField(default=timezone.now)
    updatedAt = models.DateTimeField(default=timezone.now)