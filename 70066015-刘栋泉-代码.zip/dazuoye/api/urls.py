from django.urls import path

from api.views import *


urlpatterns = [
    path('home/', HomeView.as_view(), name='home'),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(), name='login'),
    path('adduser/', AddUserView.as_view(), name='addUser'),
    path('deleteuser/', DeleteUserView.as_view(), name='deleteUser'),
    path('user/addpermission/', AddUserPermissionView.as_view(), name='deleteUser'),
    path('user/removepermission/', RemoveUserPermissionView.as_view(), name='deleteUser'),
    

    
    path('request/', RequestView.as_view(), name='requestView'),
    path('addrequest/', AddRequestView.as_view(), name='addRequestView'),
    
    path('resolve/', ResolveView.as_view(), name='resolveView'),
    path('resolve/accept/', ResolveAcceptView.as_view(), name='resolveAcceptView'),
    path('resolve/reject/', ResolveRejectView.as_view(), name='resolveRejectView'),

    
    path('resource/', ResourceView.as_view(), name='resourceView'),
    path('addresource/', AddResourceView.as_view(), name='addResourceView'),

    path('notification/', NotificationView.as_view(), name='notificationView'),
    


]