from django import forms


class LoginForm(forms.Form):
    username = forms.CharField(label="username", max_length=8, widget=forms.TextInput(attrs={'class': 'form-control'}))
    password = forms.CharField(label="密码", max_length=64, widget=forms.PasswordInput(attrs={'class': 'form-control'}))


class AddUserForm(forms.Form):
    username = forms.CharField(label="姓名", max_length=30, widget=forms.TextInput(attrs={'class': 'form-control'}))
    gender = forms.CharField(label="性别", max_length=30, widget=forms.TextInput(attrs={'class': 'form-control'}))
    phone = forms.CharField(label="手机号", max_length=30, widget=forms.TextInput(attrs={'class': 'form-control'}))
    password = forms.CharField(label="密码", min_length=6, max_length=64, widget=forms.PasswordInput(attrs={'class': 'form-control'}))
    email =forms.CharField(label="邮箱", max_length=150, widget=forms.EmailInput(attrs={'class': 'form-control'}))


class AddRequestForm(forms.Form):
    productname = forms.CharField(label="物件名称", max_length=255, widget=forms.TextInput(attrs={'class': 'form-control'}))
    producttype = forms.CharField(label="物价类型", max_length=255, widget=forms.TextInput(attrs={'class': 'form-control'}))
    qty = forms.CharField(label="数量", max_length=255, widget=forms.TextInput(attrs={'class': 'form-control'}))
    address = forms.CharField(label="地址", max_length=255, widget=forms.TextInput(attrs={'class': 'form-control'}))
    price = forms.CharField(label="金额", max_length=255, widget=forms.TextInput(attrs={'class': 'form-control'}))


class AddResourceForm(forms.Form):
    productname = forms.CharField(label="物件名称", max_length=255, widget=forms.TextInput(attrs={'class': 'form-control'}))
    producttype = forms.CharField(label="物价类型", max_length=255, widget=forms.TextInput(attrs={'class': 'form-control'}))
    qty = forms.CharField(label="数量", max_length=255, widget=forms.TextInput(attrs={'class': 'form-control'}))
    price = forms.CharField(label="金额", max_length=255, widget=forms.TextInput(attrs={'class': 'form-control'}))


class SearchForm(forms.Form):
    keyword = forms.CharField(label="关键词", max_length=60,widget=forms.TextInput(attrs={'class':'form-control', 'placeholder': '请输入关键词'}))